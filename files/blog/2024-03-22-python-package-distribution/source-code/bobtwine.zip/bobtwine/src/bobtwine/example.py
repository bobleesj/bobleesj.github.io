def square(number):
    return number**2
