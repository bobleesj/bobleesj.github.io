from bobtwine import example

value = example.square(2)
print(value)
