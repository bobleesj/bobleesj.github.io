## Tutorial

[How to distribute Python package with pip (Ft. Twine)](https://bobleesj.github.io/tutorial/2024/03/22/python-package.html)


## PyPI

https://pypi.org/project/bobtwine/